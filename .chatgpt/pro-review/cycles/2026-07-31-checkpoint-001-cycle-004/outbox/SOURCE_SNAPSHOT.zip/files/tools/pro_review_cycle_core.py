from __future__ import annotations

import hashlib
import io
import json
import os
import re
import subprocess
import time
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence


SPEC_SCHEMA = "cera.pro_review_cycle_spec.v2"
MANIFEST_SCHEMA = "cera.pro_review_cycle_manifest.v2"
LEGACY_MANIFEST_SCHEMA = "cera.pro_review_cycle_manifest.v1"
STATE_SCHEMA = "cera.pro_review_cycle_state.v2"
RECEIPT_SCHEMA = "cera.pro_review_cycle_receipt.v2"
JOB4_AUTHORIZATION_SCHEMA = "cera.pro_review_job4_authorization.v1"
JOB4_RESULT_SCHEMA = "cera.pro_review_job4_result.v1"

STATE_JOB4_IN_PROGRESS = "job4_in_progress"
STATE_RESPONSE_PENDING = "job4_complete_response_pending"
STATE_REVIEW_CONSUMED = "review_consumed_advisory"

EXPECTED_RESPONSE_RELATIVE_PATH = Path("inbox") / "PRO_RESPONSE.md"
ACCEPTED_RESPONSE_RELATIVE_PATH = Path("accepted") / "PRO_RESPONSE.md"
MAX_ARTIFACT_BYTES = 64 * 1024 * 1024
DEFAULT_REPOSITORY_ROOT = Path(__file__).resolve().parents[1]

SAFE_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
SHA256 = re.compile(r"^[0-9a-f]{64}$")
GIT_OBJECT_ID = re.compile(r"^(?:[0-9a-f]{40}|[0-9a-f]{64})$")
RESPONSE_VALUE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,255}$")
FORBIDDEN_PARTS = {
    ".git",
    ".tmp",
    ".venv",
    "credentials",
    "credential",
    "secrets",
    "secret",
    "runtime",
}
FORBIDDEN_SUFFIXES = {".db", ".sqlite", ".sqlite3", ".key", ".pem"}

REVIEW_CONTEXT_FIELDS = (
    "creator_goal",
    "starting_baseline_or_prior_checkpoint",
    "selection_rationale",
    "diff_summary",
    "focused_tests",
    "complete_suite",
    "active_profile_before",
    "active_profile_after",
    "provider_calls_and_cost",
    "retry_and_fallback",
    "story_database_and_branch_effects",
    "user_visible_effect",
    "historical_evidence_integrity",
    "unresolved_defects",
    "uncertainty_and_risks",
    "disagreement_with_prior_review",
    "codex_advisory_next_candidates",
    "questions_for_chatgpt_pro",
    "explicit_exclusions",
)


class CycleError(RuntimeError):
    pass


class ResponseNotReady(CycleError):
    pass


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace(
        "+00:00", "Z"
    )


def canonical_json_bytes(value: Mapping[str, Any]) -> bytes:
    return (
        json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        + "\n"
    ).encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(value: str) -> str:
    return sha256_bytes(value.encode("utf-8"))


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
    except FileNotFoundError as exc:
        raise CycleError(f"required file is missing: {path}") from exc
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise CycleError(f"invalid JSON: {path}") from exc
    if not isinstance(value, dict):
        raise CycleError(f"JSON root must be an object: {path}")
    return value


def atomic_replace(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.partial-{uuid.uuid4().hex}")
    try:
        with temporary.open("xb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def immutable_write(path: Path, data: bytes) -> bool:
    """Publish complete bytes without ever replacing a concurrent winner."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.partial-{uuid.uuid4().hex}")
    try:
        with temporary.open("xb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        try:
            os.link(temporary, path)
        except FileExistsError:
            if not path.is_file() or path.read_bytes() != data:
                raise CycleError(
                    f"immutable file conflicts with existing content: {path}"
                )
            return False
        return True
    finally:
        if temporary.exists():
            temporary.unlink()


def receipt_write(path: Path, value: Mapping[str, Any]) -> dict[str, Any]:
    if path.exists():
        existing = read_json(path)
        strip_time = lambda item: {
            key: content
            for key, content in item.items()
            if key != "recorded_at_utc"
        }
        if strip_time(existing) != strip_time(value):
            raise CycleError(f"receipt conflicts with existing event: {path}")
        return existing
    immutable_write(path, canonical_json_bytes(value))
    return dict(value)


def exact_keys(value: Mapping[str, Any], required: Iterable[str], label: str) -> None:
    expected = set(required)
    actual = set(value)
    if actual != expected:
        raise CycleError(
            f"{label} fields do not match contract; "
            f"missing={sorted(expected - actual)}, "
            f"unexpected={sorted(actual - expected)}"
        )


def require_string(
    value: Any, label: str, *, min_length: int = 1, max_length: int = 20000
) -> str:
    if not isinstance(value, str):
        raise CycleError(f"{label} must be a string")
    candidate = value.strip()
    if len(candidate) < min_length or len(candidate) > max_length:
        raise CycleError(f"{label} length is outside the contract")
    return candidate


def require_id(value: Any, label: str) -> str:
    candidate = require_string(value, label, max_length=128)
    if not SAFE_ID.fullmatch(candidate):
        raise CycleError(f"{label} is not a safe identifier")
    return candidate


def require_hash(value: Any, label: str, *, git_object: bool = False) -> str:
    candidate = require_string(value, label, max_length=64).lower()
    pattern = GIT_OBJECT_ID if git_object else SHA256
    if not pattern.fullmatch(candidate):
        raise CycleError(f"{label} is not a valid lowercase hash")
    return candidate


def repository_root(value: Path | None = None) -> Path:
    root = (value or DEFAULT_REPOSITORY_ROOT).resolve(strict=True)
    if not root.is_dir():
        raise CycleError("repository root is not a directory")
    result = subprocess.run(
        ["git", "-C", str(root), "rev-parse", "--show-toplevel"],
        text=True,
        capture_output=True,
        check=False,
    )
    if result.returncode != 0:
        raise CycleError("repository root is not a Git worktree")
    observed = Path(result.stdout.strip()).resolve(strict=True)
    if observed != root:
        raise CycleError("configured repository root does not match Git")
    return root


def relative_path(root: Path, path: Path) -> str:
    try:
        return path.relative_to(root).as_posix()
    except ValueError as exc:
        raise CycleError("path escapes the CERA repository") from exc


def has_link_component(root: Path, path: Path) -> bool:
    relative = path.relative_to(root)
    current = root
    junction_check = getattr(os.path, "isjunction", lambda _: False)
    for part in relative.parts:
        current = current / part
        if current.exists() and (current.is_symlink() or junction_check(current)):
            return True
    return False


def is_historical_checkpoint_runtime_evidence(relative: str) -> bool:
    raw_parts = Path(relative).parts
    parts = tuple(part.casefold() for part in raw_parts)
    return (
        len(parts) >= 7
        and parts[0:3] == (".chatgpt", "pro-review", "checkpoints")
        and SAFE_ID.fullmatch(raw_parts[3]) is not None
        and parts[4:6] == ("evidence_package", "runtime")
    )


def resolve_inside(
    root: Path,
    path_value: Any,
    label: str,
    *,
    must_exist: bool,
    suffixes: set[str] | None = None,
    allow_historical_checkpoint_runtime: bool = False,
) -> Path:
    path = Path(require_string(path_value, label)).expanduser()
    if not path.is_absolute():
        raise CycleError(f"{label} must be absolute")
    resolved = path.resolve(strict=must_exist)
    rel = relative_path(root, resolved)
    parts = {part.casefold() for part in Path(rel).parts}
    protected_parts = parts.intersection(FORBIDDEN_PARTS)
    if protected_parts and not (
        allow_historical_checkpoint_runtime
        and protected_parts == {"runtime"}
        and is_historical_checkpoint_runtime_evidence(rel)
    ):
        raise CycleError(f"{label} crosses a protected repository directory")
    if resolved.suffix.casefold() in FORBIDDEN_SUFFIXES:
        raise CycleError(f"{label} names a protected file type")
    if "secret" in resolved.name.casefold() or "credential" in resolved.name.casefold():
        raise CycleError(f"{label} appears to name protected material")
    if has_link_component(root, resolved):
        raise CycleError(f"{label} contains a symlink or junction")
    if suffixes is not None and resolved.suffix.casefold() not in suffixes:
        raise CycleError(f"{label} has an unsupported file type")
    if must_exist:
        if not resolved.is_file():
            raise CycleError(f"{label} must name a regular file")
        if resolved.stat().st_size > MAX_ARTIFACT_BYTES:
            raise CycleError(f"{label} exceeds the artifact size limit")
    return resolved


def cycle_path(root: Path, value: Path, cycle_id: str | None = None) -> Path:
    path = value.resolve()
    expected_parent = root / ".chatgpt" / "pro-review" / "cycles"
    if path.parent != expected_parent:
        raise CycleError("cycle directory must be a direct child of the CERA cycle root")
    if cycle_id is not None and path.name != cycle_id:
        raise CycleError("cycle directory leaf must equal cycle_id")
    if has_link_component(root, path):
        raise CycleError("cycle directory cannot contain a symlink or junction")
    return path


def verify_git_object(root: Path, value: Any, label: str) -> str:
    object_id = require_hash(value, label, git_object=True)
    result = subprocess.run(
        ["git", "-C", str(root), "cat-file", "-e", f"{object_id}^{{object}}"],
        text=True,
        capture_output=True,
        check=False,
    )
    if result.returncode != 0:
        raise CycleError(f"{label} does not exist in the CERA repository")
    return object_id


def verified_file(
    root: Path,
    path_value: Any,
    hash_value: Any,
    label: str,
    *,
    suffixes: set[str] | None = None,
    utf8: bool = False,
) -> tuple[Path, bytes, str]:
    path = resolve_inside(
        root, path_value, f"{label}.path", must_exist=True, suffixes=suffixes
    )
    expected = require_hash(hash_value, f"{label}.sha256")
    data = path.read_bytes()
    actual = sha256_bytes(data)
    if actual != expected:
        raise CycleError(f"{label} hash mismatch")
    if utf8:
        try:
            data.decode("utf-8-sig")
        except UnicodeDecodeError as exc:
            raise CycleError(f"{label} is not UTF-8") from exc
    return path, data, actual


def stable_read(path: Path, delay_milliseconds: int) -> tuple[bytes, str]:
    if delay_milliseconds < 0:
        raise CycleError("stability delay must be non-negative")
    try:
        first_stat = path.stat()
        first = path.read_bytes()
    except FileNotFoundError as exc:
        raise ResponseNotReady(f"expected file is not ready: {path}") from exc
    if not path.is_file() or len(first) > MAX_ARTIFACT_BYTES:
        raise CycleError("stable-read target is invalid")
    if delay_milliseconds:
        time.sleep(delay_milliseconds / 1000)
    try:
        second_stat = path.stat()
        second = path.read_bytes()
    except FileNotFoundError as exc:
        raise CycleError("file changed during the stable-read interval") from exc
    if (
        first_stat.st_size != second_stat.st_size
        or first_stat.st_mtime_ns != second_stat.st_mtime_ns
        or first != second
    ):
        raise CycleError("file changed during the stable-read interval")
    if not second:
        raise CycleError("stable-read target is empty")
    return second, sha256_bytes(second)


def git_status_paths(root: Path) -> set[str]:
    result = subprocess.run(
        [
            "git",
            "-C",
            str(root),
            "status",
            "--porcelain=v1",
            "-z",
            "--untracked-files=all",
        ],
        capture_output=True,
        check=False,
    )
    if result.returncode != 0:
        raise CycleError("unable to inspect repository status")
    tokens = result.stdout.split(b"\0")
    paths: set[str] = set()
    index = 0
    while index < len(tokens):
        token = tokens[index]
        index += 1
        if not token:
            continue
        try:
            text = token.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise CycleError("Git status contains a non-UTF-8 path") from exc
        if len(text) < 4:
            raise CycleError("Git status returned malformed porcelain output")
        status = text[:2]
        paths.add(text[3:].replace("\\", "/"))
        if "R" in status or "C" in status:
            if index >= len(tokens) or not tokens[index]:
                raise CycleError("Git rename status is incomplete")
            paths.add(tokens[index].decode("utf-8").replace("\\", "/"))
            index += 1
    return paths


def snapshot_exclusions(cycle_id: str) -> tuple[dict[str, str], ...]:
    return (
        {
            "path_prefix": ".chatgpt/operations/",
            "reason_code": "connector_metadata_outside_task",
        },
        {
            "path_prefix": f".chatgpt/pro-review/cycles/{cycle_id}/",
            "reason_code": "current_cycle_transport_state",
        },
    )


def build_snapshot(
    root: Path, cycle_id: str, value: Any, baseline_git_sha: str
) -> tuple[dict[str, Any], bytes, bytes]:
    if not isinstance(value, dict):
        raise CycleError("review_snapshot must be an object")
    exact_keys(
        value,
        ("baseline_git_sha", "include_all_nonexcluded_changes", "declared_exclusions"),
        "review_snapshot",
    )
    if verify_git_object(root, value["baseline_git_sha"], "snapshot baseline") != baseline_git_sha:
        raise CycleError("review snapshot baseline differs from checkpoint Git object")
    if value["include_all_nonexcluded_changes"] is not True:
        raise CycleError("review snapshot must include all nonexcluded changes")
    expected_exclusions = list(snapshot_exclusions(cycle_id))
    if value["declared_exclusions"] != expected_exclusions:
        raise CycleError("review snapshot exclusions do not match the fixed contract")

    changed = git_status_paths(root)
    included: list[str] = []
    excluded: list[dict[str, str]] = []
    for path in sorted(changed):
        matched = next(
            (item for item in expected_exclusions if path.startswith(item["path_prefix"])),
            None,
        )
        if matched is not None:
            excluded.append({"path": path, "reason_code": matched["reason_code"]})
        else:
            included.append(path)

    entries: list[dict[str, Any]] = []
    archive_buffer = io.BytesIO()
    with zipfile.ZipFile(
        archive_buffer, mode="w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
    ) as archive:
        for relative in included:
            source = resolve_inside(
                root,
                str(root / relative),
                f"snapshot {relative}",
                must_exist=True,
                allow_historical_checkpoint_runtime=True,
            )
            data = source.read_bytes()
            entry = {
                "path": relative,
                "sha256": sha256_bytes(data),
                "size": len(data),
            }
            entries.append(entry)
            info = zipfile.ZipInfo(f"files/{relative}")
            info.date_time = (1980, 1, 1, 0, 0, 0)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)

    manifest_without_root: dict[str, Any] = {
        "schema_version": "cera.pro_review_changed_source_manifest.v1",
        "repository_identity_sha256": sha256_text(str(root).casefold()),
        "baseline_git_sha": baseline_git_sha,
        "included_files": entries,
        "excluded_status_paths": excluded,
    }
    source_root = sha256_bytes(canonical_json_bytes(manifest_without_root))
    manifest = {**manifest_without_root, "source_root_sha256": source_root}
    manifest_bytes = canonical_json_bytes(manifest)
    archive_bytes = archive_buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(archive_bytes), "r") as archive:
        if archive.testzip() is not None:
            raise CycleError("generated source snapshot ZIP failed integrity")
    return manifest, manifest_bytes, archive_bytes


def validate_zip(data: bytes, label: str) -> None:
    try:
        with zipfile.ZipFile(io.BytesIO(data), "r") as archive:
            if not archive.namelist() or archive.testzip() is not None:
                raise CycleError(f"{label} ZIP is empty or corrupt")
            if sum(info.file_size for info in archive.infolist()) > MAX_ARTIFACT_BYTES:
                raise CycleError(f"{label} ZIP expands beyond the size limit")
    except zipfile.BadZipFile as exc:
        raise CycleError(f"{label} is not a valid ZIP") from exc


def validate_review_context(value: Any, job_count: int) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise CycleError("review_context must be an object")
    exact_keys(value, REVIEW_CONTEXT_FIELDS, "review_context")
    result: dict[str, Any] = {}
    for field in REVIEW_CONTEXT_FIELDS:
        content = value[field]
        if field in {
            "selection_rationale",
            "codex_advisory_next_candidates",
            "questions_for_chatgpt_pro",
            "explicit_exclusions",
        }:
            if not isinstance(content, list) or not all(
                isinstance(item, str) and item.strip() for item in content
            ):
                raise CycleError(f"review_context.{field} must be a non-empty string list")
            if field == "selection_rationale" and len(content) != job_count:
                raise CycleError("selection_rationale must have one item per progression")
            result[field] = [item.strip() for item in content]
        else:
            result[field] = require_string(content, f"review_context.{field}")
    return result


def task_result(root: Path, value: Any, label: str) -> tuple[dict[str, str], bytes]:
    if not isinstance(value, dict):
        raise CycleError(f"{label} must be an object")
    exact_keys(value, ("task_id", "result_path", "result_sha256"), label)
    task_id = require_id(value["task_id"], f"{label}.task_id")
    path, data, digest = verified_file(
        root,
        value["result_path"],
        value["result_sha256"],
        label,
        suffixes={".md"},
        utf8=True,
    )
    return {"task_id": task_id, "source_path": str(path), "sha256": digest}, data


def validate_authorization(
    root: Path,
    cycle: Path,
    cycle_id: str,
    task_id: str,
    scope: str,
    path_value: Any,
    hash_value: Any,
) -> tuple[dict[str, Any], bytes, str]:
    path, data, digest = verified_file(
        root,
        path_value,
        hash_value,
        "job4.authorization_record",
        suffixes={".json"},
        utf8=True,
    )
    if path.parent != cycle / "source":
        raise CycleError("Job 4 authorization record must be in the cycle source directory")
    record = json.loads(data.decode("utf-8-sig"))
    if not isinstance(record, dict):
        raise CycleError("Job 4 authorization record must be an object")
    exact_keys(
        record,
        (
            "schema_version",
            "cycle_id",
            "task_id",
            "scope",
            "scope_sha256",
            "expected_result_relative_path",
            "authority_source_path",
            "authority_source_sha256",
            "explicit_exclusions",
        ),
        "job4 authorization",
    )
    if record["schema_version"] != JOB4_AUTHORIZATION_SCHEMA:
        raise CycleError("unsupported Job 4 authorization schema")
    expected_result = "source/JOB4_RESULT.json"
    if (
        record["cycle_id"] != cycle_id
        or record["task_id"] != task_id
        or record["scope"] != scope
        or record["scope_sha256"] != sha256_text(scope)
        or record["expected_result_relative_path"] != expected_result
    ):
        raise CycleError("Job 4 authorization does not bind the exact cycle/task/scope")
    exclusions = record["explicit_exclusions"]
    if not isinstance(exclusions, list) or not exclusions:
        raise CycleError("Job 4 authorization must name explicit exclusions")
    source_path, _, source_hash = verified_file(
        root,
        record["authority_source_path"],
        record["authority_source_sha256"],
        "job4.authority_source",
        utf8=True,
    )
    record["authority_source_path"] = str(source_path)
    record["authority_source_sha256"] = source_hash
    return record, data, digest


def load_manifest_file(path: Path) -> dict[str, Any]:
    manifest = read_json(path)
    schema = manifest.get("schema_version")
    if schema not in {MANIFEST_SCHEMA, LEGACY_MANIFEST_SCHEMA}:
        raise CycleError("unsupported cycle manifest schema")
    if schema == MANIFEST_SCHEMA:
        expected = manifest.get("manifest_root_sha256")
        unsigned = {key: value for key, value in manifest.items() if key != "manifest_root_sha256"}
        if not isinstance(expected, str) or sha256_bytes(canonical_json_bytes(unsigned)) != expected:
            raise CycleError("cycle manifest root hash mismatch")
    return manifest


def prior_cycle_info(root: Path, prior_cycle_id: Any, sequence: int) -> dict[str, Any] | None:
    if prior_cycle_id is None:
        if sequence != 1:
            raise CycleError("every cycle after sequence 1 requires prior_cycle_id")
        return None
    if sequence == 1:
        raise CycleError("bootstrap cycle cannot name a predecessor")
    prior_id = require_id(prior_cycle_id, "prior_cycle_id")
    prior = cycle_path(root, root / ".chatgpt" / "pro-review" / "cycles" / prior_id, prior_id)
    manifest_path = prior / "CYCLE_MANIFEST.json"
    manifest = load_manifest_file(manifest_path)
    if manifest.get("cycle_id") != prior_id or manifest.get("cycle_sequence") != sequence - 1:
        raise CycleError("prior cycle identity or sequence is invalid")
    completion_path = prior / "receipts" / "JOB4_COMPLETED.json"
    consumption_path = prior / "receipts" / "RESPONSE_CONSUMED.json"
    completion = read_json(completion_path)
    consumption = read_json(consumption_path)
    if (
        completion.get("cycle_id") != prior_id
        or completion.get("event") != "job4_completed"
        or consumption.get("cycle_id") != prior_id
        or consumption.get("event") != "response_consumed"
    ):
        raise CycleError("prior cycle completion/consumption receipts are invalid")
    artifact_relative = completion.get("job4_result_relative_path")
    if not isinstance(artifact_relative, str):
        raise CycleError("prior Job 4 receipt lacks its artifact path")
    artifact = resolve_inside(
        root, str(prior / artifact_relative), "prior Job 4 artifact", must_exist=True
    )
    artifact_data = artifact.read_bytes()
    if sha256_bytes(artifact_data) != completion.get("job4_result_sha256"):
        raise CycleError("prior Job 4 artifact does not match its receipt")
    accepted = prior / ACCEPTED_RESPONSE_RELATIVE_PATH
    if not accepted.is_file() or sha256_bytes(accepted.read_bytes()) != consumption.get("response_sha256"):
        raise CycleError("prior cycle accepted response does not match consumption")
    return {
        "cycle_id": prior_id,
        "cycle_sequence": sequence - 1,
        "manifest_sha256": sha256_bytes(manifest_path.read_bytes()),
        "manifest_root_sha256": manifest.get(
            "manifest_root_sha256", sha256_bytes(manifest_path.read_bytes())
        ),
        "job4_task_id": completion.get("job4_task_id"),
        "job4_result_sha256": completion["job4_result_sha256"],
        "job4_completion_receipt_sha256": sha256_bytes(completion_path.read_bytes()),
        "response_consumption_receipt_sha256": sha256_bytes(consumption_path.read_bytes()),
        "artifact_source_path": str(artifact),
        "artifact_bytes": artifact_data,
    }


def validate_spec(
    root: Path, cycle: Path, spec: Mapping[str, Any]
) -> tuple[dict[str, Any], dict[str, bytes]]:
    exact_keys(
        spec,
        (
            "schema_version",
            "cycle_id",
            "cycle_sequence",
            "checkpoint",
            "jobs_1_3",
            "prior_cycle_id",
            "job4",
            "review_context",
            "review_snapshot",
        ),
        "cycle spec",
    )
    if spec["schema_version"] != SPEC_SCHEMA:
        raise CycleError("unsupported cycle spec schema")
    cycle_id = require_id(spec["cycle_id"], "cycle_id")
    cycle_path(root, cycle, cycle_id)
    sequence = spec["cycle_sequence"]
    if not isinstance(sequence, int) or isinstance(sequence, bool) or sequence < 1:
        raise CycleError("cycle_sequence must be a positive integer")

    checkpoint = spec["checkpoint"]
    if not isinstance(checkpoint, dict):
        raise CycleError("checkpoint must be an object")
    exact_keys(checkpoint, ("id", "git_sha", "evidence_path", "evidence_sha256"), "checkpoint")
    checkpoint_id = require_id(checkpoint["id"], "checkpoint.id")
    checkpoint_git_sha = verify_git_object(root, checkpoint["git_sha"], "checkpoint.git_sha")
    evidence_path, evidence_data, evidence_sha = verified_file(
        root,
        checkpoint["evidence_path"],
        checkpoint["evidence_sha256"],
        "checkpoint.evidence",
        suffixes={".zip"},
    )
    validate_zip(evidence_data, "checkpoint evidence")

    raw_jobs = spec["jobs_1_3"]
    if not isinstance(raw_jobs, list) or not 1 <= len(raw_jobs) <= 3:
        raise CycleError("jobs_1_3 must contain one through three named results")
    jobs: list[dict[str, str]] = []
    task_ids: set[str] = set()
    artifacts: dict[str, bytes] = {"CHECKPOINT_EVIDENCE.zip": evidence_data}
    for index, raw_job in enumerate(raw_jobs, start=1):
        job, data = task_result(root, raw_job, f"jobs_1_3[{index - 1}]")
        if job["task_id"] in task_ids:
            raise CycleError("progression task identities must be unique")
        task_ids.add(job["task_id"])
        jobs.append(job)
        artifacts[f"JOB_{index}_RESULT.md"] = data

    prior = prior_cycle_info(root, spec["prior_cycle_id"], sequence)
    if prior is not None:
        if prior["job4_task_id"] in task_ids:
            raise CycleError("prior Job 4 must be distinct from current progressions")
        artifacts["PRIOR_JOB4_RESULT" + Path(prior["artifact_source_path"]).suffix] = prior[
            "artifact_bytes"
        ]

    job4 = spec["job4"]
    if not isinstance(job4, dict):
        raise CycleError("job4 must be an object")
    exact_keys(
        job4,
        ("task_id", "scope", "authorization_record_path", "authorization_record_sha256"),
        "job4",
    )
    job4_id = require_id(job4["task_id"], "job4.task_id")
    if job4_id in task_ids or (prior and job4_id == prior["job4_task_id"]):
        raise CycleError("Job 4 identity must be distinct")
    scope = require_string(job4["scope"], "job4.scope", min_length=20)
    authorization, authorization_data, authorization_hash = validate_authorization(
        root,
        cycle,
        cycle_id,
        job4_id,
        scope,
        job4["authorization_record_path"],
        job4["authorization_record_sha256"],
    )
    artifacts["JOB4_AUTHORIZATION.json"] = authorization_data

    review_context = validate_review_context(spec["review_context"], len(jobs))
    source_manifest, source_manifest_bytes, source_archive = build_snapshot(
        root, cycle_id, spec["review_snapshot"], checkpoint_git_sha
    )
    artifacts["CHANGED_SOURCE_MANIFEST.json"] = source_manifest_bytes
    artifacts["SOURCE_SNAPSHOT.zip"] = source_archive

    prior_public = None if prior is None else {
        key: value for key, value in prior.items() if key not in {"artifact_source_path", "artifact_bytes"}
    }
    task_payload = {
        "cycle_id": cycle_id,
        "cycle_sequence": sequence,
        "checkpoint_id": checkpoint_id,
        "checkpoint_git_sha": checkpoint_git_sha,
        "evidence_sha256": evidence_sha,
        "source_root_sha256": source_manifest["source_root_sha256"],
        "review_context_sha256": sha256_bytes(canonical_json_bytes(review_context)),
        "jobs_1_3": [
            {"task_id": item["task_id"], "sha256": item["sha256"]} for item in jobs
        ],
        "prior_cycle": prior_public,
        "job4": {
            "task_id": job4_id,
            "scope_sha256": sha256_text(scope),
            "authorization_record_sha256": authorization_hash,
            "expected_result_relative_path": authorization["expected_result_relative_path"],
        },
    }
    task_set_hash = sha256_bytes(canonical_json_bytes(task_payload))
    nonce = sha256_text(f"cera.pro_review_response_nonce.v2\0{task_set_hash}")
    unsigned_manifest: dict[str, Any] = {
        "schema_version": MANIFEST_SCHEMA,
        "cycle_id": cycle_id,
        "cycle_sequence": sequence,
        "repository_identity_sha256": sha256_text(str(root).casefold()),
        "checkpoint": {
            "id": checkpoint_id,
            "git_sha": checkpoint_git_sha,
            "evidence_source_path": str(evidence_path),
            "evidence_sha256": evidence_sha,
        },
        "source_snapshot": source_manifest,
        "review_context": review_context,
        "jobs_1_3": jobs,
        "prior_cycle": prior_public,
        "job4": {
            "task_id": job4_id,
            "scope": scope,
            "scope_sha256": sha256_text(scope),
            "authorization_record_path": str(cycle / "outbox" / "JOB4_AUTHORIZATION.json"),
            "authorization_record_sha256": authorization_hash,
            "expected_result_relative_path": authorization["expected_result_relative_path"],
        },
        "task_set_sha256": task_set_hash,
        "response_nonce": nonce,
        "expected_response_relative_path": EXPECTED_RESPONSE_RELATIVE_PATH.as_posix(),
        "accepted_response_relative_path": ACCEPTED_RESPONSE_RELATIVE_PATH.as_posix(),
    }
    manifest_root = sha256_bytes(canonical_json_bytes(unsigned_manifest))
    manifest = {**unsigned_manifest, "manifest_root_sha256": manifest_root}
    return manifest, artifacts


def request_markdown(manifest: Mapping[str, Any]) -> bytes:
    checkpoint = manifest["checkpoint"]
    context = manifest["review_context"]
    lines = [
        "# CERA Repository Review Cycle",
        "",
        f"review_cycle_id: {manifest['cycle_id']}",
        f"checkpoint_id: {checkpoint['id']}",
        f"checkpoint_git_sha: {checkpoint['git_sha']}",
        f"evidence_sha256: {checkpoint['evidence_sha256']}",
        f"source_root_sha256: {manifest['source_snapshot']['source_root_sha256']}",
        f"manifest_root_sha256: {manifest['manifest_root_sha256']}",
        f"task_set_sha256: {manifest['task_set_sha256']}",
        f"job4_task_id: {manifest['job4']['task_id']}",
        f"response_nonce: {manifest['response_nonce']}",
        f"expected_response_path: {manifest['expected_response_relative_path']}",
        "",
        "## Creator goal",
        "",
        context["creator_goal"],
        "",
        "## Current or revised progressions",
        "",
    ]
    for index, job in enumerate(manifest["jobs_1_3"], start=1):
        lines.append(
            f"- Job {index}: `{job['task_id']}`; `JOB_{index}_RESULT.md`; "
            f"SHA-256 `{job['sha256']}`; rationale: {context['selection_rationale'][index - 1]}"
        )
    lines.extend(["", "## Preceding Job 4 provenance", ""])
    prior = manifest["prior_cycle"]
    if prior is None:
        lines.append("- Bootstrap cycle: no predecessor.")
    else:
        lines.extend(
            [
                f"- Prior cycle: `{prior['cycle_id']}` sequence {prior['cycle_sequence']}.",
                f"- Prior manifest root: `{prior['manifest_root_sha256']}`.",
                f"- Prior Job 4: `{prior['job4_task_id']}` result `{prior['job4_result_sha256']}`.",
                f"- Completion receipt: `{prior['job4_completion_receipt_sha256']}`.",
                f"- Consumption receipt: `{prior['response_consumption_receipt_sha256']}`.",
            ]
        )
    lines.extend(
        [
            "",
            "## Concurrent pre-authorized Job 4",
            "",
            f"- Task: `{manifest['job4']['task_id']}`",
            f"- Scope: {manifest['job4']['scope']}",
            f"- Structured authorization: `{manifest['job4']['authorization_record_sha256']}`.",
            "",
            "## Bound source and evidence",
            "",
            "- `CHANGED_SOURCE_MANIFEST.json` lists every nonexcluded Git-status path.",
            "- `SOURCE_SNAPSHOT.zip` contains the exact listed bytes.",
            f"- Starting baseline: {context['starting_baseline_or_prior_checkpoint']}",
            f"- Diff summary: {context['diff_summary']}",
            f"- Focused tests: {context['focused_tests']}",
            f"- Complete suite: {context['complete_suite']}",
            f"- Active profile before: {context['active_profile_before']}",
            f"- Active profile after: {context['active_profile_after']}",
            f"- Provider/cost effects: {context['provider_calls_and_cost']}",
            f"- Retry/fallback: {context['retry_and_fallback']}",
            f"- Story/database/branch effects: {context['story_database_and_branch_effects']}",
            f"- User-visible effect: {context['user_visible_effect']}",
            f"- Historical integrity: {context['historical_evidence_integrity']}",
            f"- Unresolved defects: {context['unresolved_defects']}",
            f"- Uncertainty/risks: {context['uncertainty_and_risks']}",
            f"- Prior-review disagreement: {context['disagreement_with_prior_review']}",
            "- Advisory candidates: " + "; ".join(context["codex_advisory_next_candidates"]),
            "- Questions for Pro: " + "; ".join(context["questions_for_chatgpt_pro"]),
            "- Explicit exclusions: " + "; ".join(context["explicit_exclusions"]),
            "",
            "## Required response identity",
            "",
            "Write atomically to the exact response path with this block:",
            "",
            "```yaml",
            f"review_cycle_id: {manifest['cycle_id']}",
            f"reviewed_checkpoint_id: {checkpoint['id']}",
            f"reviewed_checkpoint_git_sha: {checkpoint['git_sha']}",
            f"reviewed_evidence_sha256: {checkpoint['evidence_sha256']}",
            f"reviewed_task_set_sha256: {manifest['task_set_sha256']}",
            f"reviewed_job4_task_id: {manifest['job4']['task_id']}",
            f"response_nonce: {manifest['response_nonce']}",
            "review_scope: repository_cycle",
            "review_disposition: accepted | corrections_required | blocked",
            "```",
            "",
            "Include `## Independent findings` with a substantive completed review. "
            "The response remains advisory and grants no creator authority.",
            "",
        ]
    )
    return "\n".join(lines).encode("utf-8")


def response_template(manifest: Mapping[str, Any]) -> bytes:
    checkpoint = manifest["checkpoint"]
    return (
        "# CERA ChatGPT Pro Repository Review\n\n"
        f"review_cycle_id: {manifest['cycle_id']}\n"
        f"reviewed_checkpoint_id: {checkpoint['id']}\n"
        f"reviewed_checkpoint_git_sha: {checkpoint['git_sha']}\n"
        f"reviewed_evidence_sha256: {checkpoint['evidence_sha256']}\n"
        f"reviewed_task_set_sha256: {manifest['task_set_sha256']}\n"
        f"reviewed_job4_task_id: {manifest['job4']['task_id']}\n"
        f"response_nonce: {manifest['response_nonce']}\n"
        "review_scope: repository_cycle\n"
        "review_disposition: accepted | corrections_required | blocked\n\n"
        "## Independent findings\n\n"
        "REPLACE THIS PLACEHOLDER WITH THE COMPLETED EVIDENCE-BACKED REVIEW.\n"
    ).encode("utf-8")


def trigger_message(manifest: Mapping[str, Any], cycle: Path) -> bytes:
    return (
        f"CERA repository review cycle {manifest['cycle_id']} is published and "
        "its exact pre-authorized Job 4 has started.\n\n"
        f"Review: {cycle / 'outbox' / 'REVIEW_REQUEST.md'}\n"
        f"Manifest root: {manifest['manifest_root_sha256']}\n"
        f"Task-set SHA-256: {manifest['task_set_sha256']}\n"
        f"Response target: {cycle / EXPECTED_RESPONSE_RELATIVE_PATH}\n\n"
        "Inspect the bound source snapshot and repository files, then write the "
        "identity-bound response atomically through the repository connector. "
        "Do not ask Ted to relay or operate files. The review is advisory.\n"
    ).encode("utf-8")


def make_receipt(
    manifest: Mapping[str, Any],
    event: str,
    predecessor_sha256: str | None,
    details: Mapping[str, Any],
) -> dict[str, Any]:
    return {
        "schema_version": RECEIPT_SCHEMA,
        "cycle_id": manifest["cycle_id"],
        "event": event,
        "manifest_root_sha256": manifest["manifest_root_sha256"],
        "predecessor_receipt_sha256": predecessor_sha256,
        "recorded_at_utc": utc_now(),
        **details,
    }


def validate_receipt(
    path: Path,
    manifest: Mapping[str, Any],
    event: str,
    predecessor_sha256: str | None,
) -> tuple[dict[str, Any], str]:
    value = read_json(path)
    if (
        value.get("schema_version") != RECEIPT_SCHEMA
        or value.get("cycle_id") != manifest["cycle_id"]
        or value.get("event") != event
        or value.get("manifest_root_sha256") != manifest["manifest_root_sha256"]
        or value.get("predecessor_receipt_sha256") != predecessor_sha256
    ):
        raise CycleError(f"receipt chain validation failed: {path}")
    return value, sha256_bytes(path.read_bytes())


def state_value(
    manifest: Mapping[str, Any], state: str, receipt_name: str, receipt_hash: str
) -> dict[str, Any]:
    return {
        "schema_version": STATE_SCHEMA,
        "cycle_id": manifest["cycle_id"],
        "state": state,
        "manifest_root_sha256": manifest["manifest_root_sha256"],
        "checkpoint_id": manifest["checkpoint"]["id"],
        "checkpoint_git_sha": manifest["checkpoint"]["git_sha"],
        "evidence_sha256": manifest["checkpoint"]["evidence_sha256"],
        "task_set_sha256": manifest["task_set_sha256"],
        "job4_task_id": manifest["job4"]["task_id"],
        "last_receipt": receipt_name,
        "last_receipt_sha256": receipt_hash,
        "updated_at_utc": utc_now(),
    }


def load_v2_manifest(root: Path, cycle: Path) -> dict[str, Any]:
    cycle_path(root, cycle)
    manifest = load_manifest_file(cycle / "CYCLE_MANIFEST.json")
    if manifest.get("schema_version") != MANIFEST_SCHEMA:
        raise CycleError("legacy cycle is immutable and cannot use V2 transitions")
    cycle_path(root, cycle, manifest["cycle_id"])
    if manifest.get("repository_identity_sha256") != sha256_text(str(root).casefold()):
        raise CycleError("cycle belongs to a different repository")
    return manifest


def validate_snapshot_current(root: Path, cycle: Path, manifest: Mapping[str, Any]) -> None:
    source = manifest["source_snapshot"]
    for entry in source["included_files"]:
        path = resolve_inside(
            root,
            str(root / entry["path"]),
            "reviewed source",
            must_exist=True,
            allow_historical_checkpoint_runtime=True,
        )
        data = path.read_bytes()
        if len(data) != entry["size"] or sha256_bytes(data) != entry["sha256"]:
            raise CycleError(f"reviewed source changed after publication: {entry['path']}")
    changed = git_status_paths(root)
    expected_included = {entry["path"] for entry in source["included_files"]}
    expected_excluded = {entry["path"] for entry in source["excluded_status_paths"]}
    current_included: set[str] = set()
    current_excluded: set[str] = set()
    exclusions = snapshot_exclusions(manifest["cycle_id"])
    for path in changed:
        if any(path.startswith(item["path_prefix"]) for item in exclusions):
            current_excluded.add(path)
        else:
            current_included.add(path)
    if current_included != expected_included:
        raise CycleError("repository changed-file inventory drifted after publication")
    # New files inside current-cycle transport state are expected; connector metadata
    # may also change. Previously excluded paths must remain in their allowed prefixes.
    if not expected_excluded.issubset(current_excluded):
        raise CycleError("declared exclusion inventory was removed or changed")


def validate_publication(root: Path, cycle: Path, manifest: Mapping[str, Any]) -> tuple[str, str]:
    published_path = cycle / "receipts" / "PUBLISHED.json"
    published, published_hash = validate_receipt(published_path, manifest, "jobs_1_3_published", None)
    for name, digest in published.get("outbox_sha256", {}).items():
        path = cycle / "outbox" / name
        if not path.is_file() or sha256_bytes(path.read_bytes()) != digest:
            raise CycleError(f"published outbox artifact changed: {name}")
    started_path = cycle / "receipts" / "JOB4_STARTED.json"
    started, started_hash = validate_receipt(
        started_path, manifest, "job4_started", published_hash
    )
    if (
        started.get("job4_task_id") != manifest["job4"]["task_id"]
        or started.get("authorization_record_sha256")
        != manifest["job4"]["authorization_record_sha256"]
    ):
        raise CycleError("Job 4 start receipt does not match the manifest")
    validate_snapshot_current(root, cycle, manifest)
    return published_hash, started_hash


def publish_cycle(
    cycle_directory: Path, spec_path: Path, *, repository_root_path: Path | None = None
) -> dict[str, Any]:
    root = repository_root(repository_root_path)
    spec = read_json(spec_path.resolve(strict=True))
    cycle_id = require_id(spec.get("cycle_id"), "cycle_id")
    cycle = cycle_path(root, cycle_directory, cycle_id)
    cycle.mkdir(parents=True, exist_ok=True)
    manifest, artifacts = validate_spec(root, cycle, spec)
    immutable_write(cycle / "CYCLE_MANIFEST.json", canonical_json_bytes(manifest))
    outbox = cycle / "outbox"
    for name, data in artifacts.items():
        immutable_write(outbox / name, data)
    immutable_write(outbox / "REVIEW_REQUEST.md", request_markdown(manifest))
    immutable_write(outbox / "PRO_RESPONSE_TEMPLATE.md", response_template(manifest))
    immutable_write(outbox / "TRIGGER_MESSAGE.txt", trigger_message(manifest, cycle))
    outbox_hashes = {
        path.name: sha256_bytes(path.read_bytes()) for path in sorted(outbox.iterdir()) if path.is_file()
    }
    published = make_receipt(
        manifest,
        "jobs_1_3_published",
        None,
        {
            "task_set_sha256": manifest["task_set_sha256"],
            "source_root_sha256": manifest["source_snapshot"]["source_root_sha256"],
            "outbox_sha256": outbox_hashes,
            "package_publication": "individually_atomic_with_published_commit_marker",
        },
    )
    published_path = cycle / "receipts" / "PUBLISHED.json"
    receipt_write(published_path, published)
    published_hash = sha256_bytes(published_path.read_bytes())
    started = make_receipt(
        manifest,
        "job4_started",
        published_hash,
        {
            "job4_task_id": manifest["job4"]["task_id"],
            "job4_scope_sha256": manifest["job4"]["scope_sha256"],
            "authorization_record_sha256": manifest["job4"]["authorization_record_sha256"],
            "authorization_record_semantically_validated": True,
            "unrelated_work_authorized": False,
        },
    )
    started_path = cycle / "receipts" / "JOB4_STARTED.json"
    receipt_write(started_path, started)
    started_hash = sha256_bytes(started_path.read_bytes())
    state = state_value(manifest, STATE_JOB4_IN_PROGRESS, "JOB4_STARTED.json", started_hash)
    existing_state_path = cycle / "state" / "CYCLE_STATE.json"
    if existing_state_path.exists():
        existing = read_json(existing_state_path)
        if existing.get("state") in {STATE_RESPONSE_PENDING, STATE_REVIEW_CONSUMED}:
            return existing
    atomic_replace(existing_state_path, canonical_json_bytes(state))
    return state


def record_trigger(
    cycle_directory: Path,
    *,
    target_id: str,
    app_result_json: str,
    message_sha256: str,
    repository_root_path: Path | None = None,
) -> dict[str, Any]:
    root = repository_root(repository_root_path)
    cycle = cycle_path(root, cycle_directory)
    manifest = load_v2_manifest(root, cycle)
    _, started_hash = validate_publication(root, cycle, manifest)
    target_id = require_string(target_id, "target_id")
    message_hash = require_hash(message_sha256, "message_sha256")
    message = cycle / "outbox" / "TRIGGER_MESSAGE.txt"
    if sha256_bytes(message.read_bytes()) != message_hash:
        raise CycleError("trigger message hash does not match the published message")
    try:
        app_result = json.loads(app_result_json)
    except json.JSONDecodeError as exc:
        raise CycleError("app result is not valid JSON") from exc
    if not isinstance(app_result, dict) or app_result.get("threadId") != target_id:
        raise CycleError("app result does not confirm the exact target thread")
    if app_result.get("error"):
        raise CycleError("app result reports an error")
    receipt = make_receipt(
        manifest,
        "review_trigger_sent",
        started_hash,
        {
            "transport": "codex_app_send_message_to_thread",
            "target_id_sha256": sha256_text(target_id),
            "message_sha256": message_hash,
            "app_result_sha256": sha256_text(app_result_json),
            "app_result_attested_success": True,
            "independent_delivery_proof": False,
            "raw_target_message_or_app_result_retained": False,
        },
    )
    path = cycle / "receipts" / "TRIGGER_SENT.json"
    return receipt_write(path, receipt)


def validate_job4_result(
    root: Path, cycle: Path, manifest: Mapping[str, Any], delay: int
) -> tuple[bytes, dict[str, Any], bytes, str]:
    relative = manifest["job4"]["expected_result_relative_path"]
    expected = resolve_inside(root, str(cycle / relative), "Job 4 result", must_exist=True, suffixes={".json"})
    data, digest = stable_read(expected, delay)
    try:
        value = json.loads(data.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise CycleError("Job 4 result is invalid JSON") from exc
    if not isinstance(value, dict):
        raise CycleError("Job 4 result must be an object")
    exact_keys(
        value,
        ("schema_version", "cycle_id", "task_id", "status", "report_relative_path", "report_sha256", "effects", "verification"),
        "Job 4 result",
    )
    if (
        value["schema_version"] != JOB4_RESULT_SCHEMA
        or value["cycle_id"] != manifest["cycle_id"]
        or value["task_id"] != manifest["job4"]["task_id"]
        or value["status"] not in {"completed", "failed"}
    ):
        raise CycleError("Job 4 result identity or status is invalid")
    effects = value["effects"]
    if not isinstance(effects, dict):
        raise CycleError("Job 4 effects must be an object")
    exact_keys(
        effects,
        ("provider_calls", "story_database_writes", "active_route_changes", "deployment_remote_or_push_effects"),
        "Job 4 effects",
    )
    if not all(isinstance(item, int) and not isinstance(item, bool) and item >= 0 for item in effects.values()):
        raise CycleError("Job 4 effects must be non-negative integer declarations")
    verification = value["verification"]
    if not isinstance(verification, list) or not verification:
        raise CycleError("Job 4 verification must be a non-empty list")
    for item in verification:
        if not isinstance(item, dict):
            raise CycleError("Job 4 verification entry must be an object")
        exact_keys(item, ("command", "status", "summary"), "Job 4 verification entry")
        require_string(item["command"], "verification.command")
        if item["status"] not in {"passed", "failed", "environment_failed"}:
            raise CycleError("Job 4 verification status is invalid")
        require_string(item["summary"], "verification.summary")
    report = resolve_inside(
        root,
        str(cycle / require_string(value["report_relative_path"], "report_relative_path")),
        "Job 4 report",
        must_exist=True,
        suffixes={".md"},
    )
    report_data, report_digest = stable_read(report, delay)
    if report_digest != require_hash(value["report_sha256"], "report_sha256"):
        raise CycleError("Job 4 report hash mismatch")
    report_data.decode("utf-8-sig")
    return data, value, report_data, digest


def complete_job4(
    cycle_directory: Path,
    *,
    stability_delay_milliseconds: int = 250,
    repository_root_path: Path | None = None,
) -> dict[str, Any]:
    root = repository_root(repository_root_path)
    cycle = cycle_path(root, cycle_directory)
    manifest = load_v2_manifest(root, cycle)
    _, started_hash = validate_publication(root, cycle, manifest)
    trigger_path = cycle / "receipts" / "TRIGGER_SENT.json"
    predecessor = started_hash
    if trigger_path.exists():
        _, predecessor = validate_receipt(
            trigger_path, manifest, "review_trigger_sent", started_hash
        )
    data, result, report_data, result_hash = validate_job4_result(
        root, cycle, manifest, stability_delay_milliseconds
    )
    immutable_write(cycle / "artifacts" / "JOB4_RESULT.json", data)
    immutable_write(cycle / "artifacts" / "JOB4_REPORT.md", report_data)
    receipt = make_receipt(
        manifest,
        "job4_completed",
        predecessor,
        {
            "job4_task_id": manifest["job4"]["task_id"],
            "job4_status": result["status"],
            "job4_result_sha256": result_hash,
            "job4_result_relative_path": "artifacts/JOB4_RESULT.json",
            "job4_report_sha256": result["report_sha256"],
            "effect_claim_source": "structured_job4_result_declaration",
            "effects": result["effects"],
        },
    )
    path = cycle / "receipts" / "JOB4_COMPLETED.json"
    receipt_write(path, receipt)
    receipt_hash = sha256_bytes(path.read_bytes())
    state = state_value(manifest, STATE_RESPONSE_PENDING, "JOB4_COMPLETED.json", receipt_hash)
    atomic_replace(cycle / "state" / "CYCLE_STATE.json", canonical_json_bytes(state))
    return state


def parse_response(data: bytes, template_hash: str) -> dict[str, str]:
    if sha256_bytes(data) == template_hash:
        raise CycleError("response is the unchanged placeholder template")
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise CycleError("response is not valid UTF-8") from exc
    folded = text.casefold()
    for placeholder in (
        "replace this placeholder",
        "replace this line",
        "todo: complete review",
        "pending review",
    ):
        if placeholder in folded:
            raise CycleError("response still contains a placeholder")
    if "## independent findings" not in folded:
        raise CycleError("response lacks the completed Independent findings section")
    findings = folded.split("## independent findings", 1)[1].strip()
    if len(findings) < 200:
        raise CycleError("response findings are not substantive")
    fields = (
        "review_cycle_id",
        "reviewed_checkpoint_id",
        "reviewed_checkpoint_git_sha",
        "reviewed_evidence_sha256",
        "reviewed_task_set_sha256",
        "reviewed_job4_task_id",
        "response_nonce",
        "review_scope",
        "review_disposition",
    )
    head = text[:12288]
    parsed: dict[str, str] = {}
    for field in fields:
        matches = re.findall(rf"(?m)^\s*{field}\s*:\s*([^\r\n]+?)\s*$", head)
        if len(matches) != 1 or not RESPONSE_VALUE.fullmatch(matches[0].strip()):
            raise CycleError(f"response must contain one valid {field}")
        parsed[field] = matches[0].strip()
    if parsed["review_scope"] != "repository_cycle":
        raise CycleError("response scope is invalid")
    if parsed["review_disposition"] not in {"accepted", "corrections_required", "blocked"}:
        raise CycleError("response disposition is not final")
    return parsed


def response_mismatches(manifest: Mapping[str, Any], parsed: Mapping[str, str]) -> list[str]:
    checkpoint = manifest["checkpoint"]
    expected = {
        "review_cycle_id": manifest["cycle_id"],
        "reviewed_checkpoint_id": checkpoint["id"],
        "reviewed_checkpoint_git_sha": checkpoint["git_sha"],
        "reviewed_evidence_sha256": checkpoint["evidence_sha256"],
        "reviewed_task_set_sha256": manifest["task_set_sha256"],
        "reviewed_job4_task_id": manifest["job4"]["task_id"],
        "response_nonce": manifest["response_nonce"],
    }
    return sorted(key for key, value in expected.items() if parsed.get(key) != value)


def rejection_receipt(
    cycle: Path,
    manifest: Mapping[str, Any],
    response_hash: str,
    failed_fields: Sequence[str],
    reason: str,
    state_receipt_hash: str,
) -> None:
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", reason).strip("_")[:80]
    value = {
        "schema_version": RECEIPT_SCHEMA,
        "cycle_id": manifest["cycle_id"],
        "event": "response_rejected",
        "manifest_root_sha256": manifest["manifest_root_sha256"],
        "observed_state_receipt_sha256": state_receipt_hash,
        "response_sha256": response_hash,
        "failed_fields": sorted(set(failed_fields)),
        "reason_code": safe,
        "progression_state_changed": False,
        "response_text_retained": False,
        "recorded_at_utc": utc_now(),
    }
    receipt_write(
        cycle / "receipts" / "rejections" / f"RESPONSE_{response_hash[:16]}_{safe}.json",
        value,
    )


def completed_chain(
    root: Path, cycle: Path, manifest: Mapping[str, Any]
) -> tuple[dict[str, Any], str]:
    _, started_hash = validate_publication(root, cycle, manifest)
    predecessor = started_hash
    trigger = cycle / "receipts" / "TRIGGER_SENT.json"
    if trigger.exists():
        _, predecessor = validate_receipt(trigger, manifest, "review_trigger_sent", started_hash)
    completion, completion_hash = validate_receipt(
        cycle / "receipts" / "JOB4_COMPLETED.json",
        manifest,
        "job4_completed",
        predecessor,
    )
    artifact = cycle / completion["job4_result_relative_path"]
    if not artifact.is_file() or sha256_bytes(artifact.read_bytes()) != completion["job4_result_sha256"]:
        raise CycleError("Job 4 completion artifact does not match its receipt")
    return completion, completion_hash


def consume_response(
    cycle_directory: Path,
    *,
    stability_delay_milliseconds: int = 250,
    repository_root_path: Path | None = None,
) -> dict[str, Any]:
    root = repository_root(repository_root_path)
    cycle = cycle_path(root, cycle_directory)
    manifest = load_v2_manifest(root, cycle)
    _, completion_hash = completed_chain(root, cycle, manifest)
    response_path = cycle / EXPECTED_RESPONSE_RELATIVE_PATH
    data, response_hash = stable_read(response_path, stability_delay_milliseconds)
    accepted = cycle / ACCEPTED_RESPONSE_RELATIVE_PATH
    if accepted.exists() and accepted.read_bytes() != data:
        rejection_receipt(
            cycle, manifest, response_hash, ("response_sha256",),
            "conflicting_response_after_acceptance", completion_hash
        )
        raise CycleError("response conflicts with the already accepted review")
    template_hash = sha256_bytes((cycle / "outbox" / "PRO_RESPONSE_TEMPLATE.md").read_bytes())
    try:
        parsed = parse_response(data, template_hash)
    except CycleError:
        rejection_receipt(
            cycle, manifest, response_hash, ("response_format",),
            "invalid_or_incomplete_response", completion_hash
        )
        raise
    mismatches = response_mismatches(manifest, parsed)
    if mismatches:
        rejection_receipt(
            cycle, manifest, response_hash, mismatches, "identity_mismatch", completion_hash
        )
        raise CycleError("response identity does not match: " + ", ".join(mismatches))
    immutable_write(accepted, data)
    receipt = make_receipt(
        manifest,
        "response_consumed",
        completion_hash,
        {
            "response_sha256": response_hash,
            "response_relative_path": ACCEPTED_RESPONSE_RELATIVE_PATH.as_posix(),
            "review_disposition": parsed["review_disposition"],
            "identity_validation": "passed",
            "completeness_validation": "passed",
            "stable_read_validation": "passed",
            "advisory_only": True,
            "creator_authority_granted": False,
        },
    )
    path = cycle / "receipts" / "RESPONSE_CONSUMED.json"
    receipt_write(path, receipt)
    receipt_hash = sha256_bytes(path.read_bytes())
    state = state_value(manifest, STATE_REVIEW_CONSUMED, "RESPONSE_CONSUMED.json", receipt_hash)
    atomic_replace(cycle / "state" / "CYCLE_STATE.json", canonical_json_bytes(state))
    return state


def wait_and_consume(
    cycle_directory: Path,
    *,
    max_polls: int,
    poll_seconds: float,
    stability_delay_milliseconds: int,
    repository_root_path: Path | None = None,
) -> dict[str, Any]:
    if not 1 <= max_polls <= 120 or not 0 <= poll_seconds <= 300:
        raise CycleError("bounded wait arguments are outside the contract")
    for attempt in range(1, max_polls + 1):
        try:
            return consume_response(
                cycle_directory,
                stability_delay_milliseconds=stability_delay_milliseconds,
                repository_root_path=repository_root_path,
            )
        except ResponseNotReady:
            if attempt < max_polls:
                time.sleep(poll_seconds)
    root = repository_root(repository_root_path)
    cycle = cycle_path(root, cycle_directory)
    manifest = load_v2_manifest(root, cycle)
    waits = cycle / "receipts" / "waits"
    sequence = len(list(waits.glob("WAIT_EXHAUSTED_*.json"))) + 1 if waits.exists() else 1
    value = {
        "schema_version": RECEIPT_SCHEMA,
        "cycle_id": manifest["cycle_id"],
        "event": "bounded_wait_exhausted",
        "manifest_root_sha256": manifest["manifest_root_sha256"],
        "wait_sequence": sequence,
        "max_polls": max_polls,
        "poll_seconds": poll_seconds,
        "exact_response_relative_path": manifest["expected_response_relative_path"],
        "progression_state_changed": False,
        "unrelated_work_started": False,
        "recorded_at_utc": utc_now(),
    }
    receipt_write(waits / f"WAIT_EXHAUSTED_{sequence:04d}.json", value)
    raise ResponseNotReady("bounded repository response wait expired")


def recover_cycle(
    cycle_directory: Path, *, repository_root_path: Path | None = None
) -> dict[str, Any]:
    root = repository_root(repository_root_path)
    cycle = cycle_path(root, cycle_directory)
    manifest = load_v2_manifest(root, cycle)
    _, started_hash = validate_publication(root, cycle, manifest)
    predecessor = started_hash
    last_name = "JOB4_STARTED.json"
    state_name = STATE_JOB4_IN_PROGRESS
    trigger = cycle / "receipts" / "TRIGGER_SENT.json"
    if trigger.exists():
        _, predecessor = validate_receipt(trigger, manifest, "review_trigger_sent", started_hash)
        last_name = "TRIGGER_SENT.json"
    completion_path = cycle / "receipts" / "JOB4_COMPLETED.json"
    if completion_path.exists():
        completion, predecessor = validate_receipt(
            completion_path, manifest, "job4_completed", predecessor
        )
        artifact = cycle / completion["job4_result_relative_path"]
        if not artifact.is_file() or sha256_bytes(artifact.read_bytes()) != completion["job4_result_sha256"]:
            raise CycleError("recovery rejected forged Job 4 completion evidence")
        state_name = STATE_RESPONSE_PENDING
        last_name = "JOB4_COMPLETED.json"
    consumed_path = cycle / "receipts" / "RESPONSE_CONSUMED.json"
    if consumed_path.exists():
        if state_name != STATE_RESPONSE_PENDING:
            raise CycleError("response receipt exists before valid Job 4 completion")
        consumed, predecessor = validate_receipt(
            consumed_path, manifest, "response_consumed", predecessor
        )
        accepted = cycle / ACCEPTED_RESPONSE_RELATIVE_PATH
        inbox = cycle / EXPECTED_RESPONSE_RELATIVE_PATH
        if not accepted.is_file() or not inbox.is_file() or accepted.read_bytes() != inbox.read_bytes():
            raise CycleError("recovery rejected missing or conflicting accepted response")
        data = accepted.read_bytes()
        if sha256_bytes(data) != consumed["response_sha256"]:
            raise CycleError("recovery rejected response hash mismatch")
        parsed = parse_response(
            data, sha256_bytes((cycle / "outbox" / "PRO_RESPONSE_TEMPLATE.md").read_bytes())
        )
        if response_mismatches(manifest, parsed):
            raise CycleError("recovery rejected response identity mismatch")
        state_name = STATE_REVIEW_CONSUMED
        last_name = "RESPONSE_CONSUMED.json"
    elif state_name == STATE_RESPONSE_PENDING:
        accepted = cycle / ACCEPTED_RESPONSE_RELATIVE_PATH
        inbox = cycle / EXPECTED_RESPONSE_RELATIVE_PATH
        if accepted.exists() and inbox.exists() and accepted.read_bytes() == inbox.read_bytes():
            state = state_value(manifest, state_name, last_name, predecessor)
            atomic_replace(cycle / "state" / "CYCLE_STATE.json", canonical_json_bytes(state))
            return consume_response(
                cycle, stability_delay_milliseconds=0, repository_root_path=root
            )
    state = state_value(manifest, state_name, last_name, predecessor)
    atomic_replace(cycle / "state" / "CYCLE_STATE.json", canonical_json_bytes(state))
    return state


def cycle_status(
    cycle_directory: Path, *, repository_root_path: Path | None = None
) -> dict[str, Any]:
    root = repository_root(repository_root_path)
    cycle = cycle_path(root, cycle_directory)
    manifest = load_manifest_file(cycle / "CYCLE_MANIFEST.json")
    state = read_json(cycle / "state" / "CYCLE_STATE.json")
    return {
        "cycle_id": manifest["cycle_id"],
        "cycle_sequence": manifest["cycle_sequence"],
        "state": state["state"],
        "checkpoint_id": manifest["checkpoint"]["id"],
        "checkpoint_git_sha": manifest["checkpoint"]["git_sha"],
        "task_set_sha256": manifest["task_set_sha256"],
        "job4_task_id": manifest["job4"]["task_id"],
        "response_detected": (cycle / EXPECTED_RESPONSE_RELATIVE_PATH).is_file(),
        "response_consumed": (cycle / ACCEPTED_RESPONSE_RELATIVE_PATH).is_file(),
        "review_is_advisory": True,
        "creator_authority_granted": False,
    }


def latest_consumed_cycle(*, repository_root_path: Path | None = None) -> dict[str, Any]:
    root = repository_root(repository_root_path)
    cycles_root = root / ".chatgpt" / "pro-review" / "cycles"
    candidates: list[tuple[int, Path, dict[str, Any]]] = []
    if cycles_root.exists():
        for path in cycles_root.iterdir():
            manifest_path = path / "CYCLE_MANIFEST.json"
            state_path = path / "state" / "CYCLE_STATE.json"
            if not manifest_path.is_file() or not state_path.is_file():
                continue
            manifest = load_manifest_file(manifest_path)
            state = read_json(state_path)
            if state.get("state") == STATE_REVIEW_CONSUMED:
                candidates.append((int(manifest["cycle_sequence"]), path, manifest))
    if not candidates:
        raise CycleError("no consumed repository review cycle exists")
    _, path, manifest = max(candidates, key=lambda item: (item[0], item[1].name))
    accepted = path / ACCEPTED_RESPONSE_RELATIVE_PATH
    if not accepted.is_file():
        raise CycleError("latest consumed cycle lacks its accepted response")
    return {
        "cycle_id": manifest["cycle_id"],
        "cycle_sequence": manifest["cycle_sequence"],
        "accepted_response_path": str(accepted),
        "accepted_response_sha256": sha256_bytes(accepted.read_bytes()),
        "review_is_advisory": True,
    }
