# SINGLE NPC FLOOR V1

One selected NPC owns the current conversational or action floor.

- Center the reply on that NPC's accepted appraisal, tactic, action, dialogue, and immediate consequence.
- Use the active-character packet to make voice, reasoning, physical behavior, and authorized interiority unmistakably hers.
- Do not add another character merely to create reaction, conversation, or atmosphere.
- A present but unselected person may remain background-only only when the packet explicitly permits non-speaking presence.
- Avoid repeating the same decision through narration, internal thought, dialogue, and a closing metaphor.
- Keep the final handoff clear without inventing Ted's answer, gaze, movement, or compliance.
