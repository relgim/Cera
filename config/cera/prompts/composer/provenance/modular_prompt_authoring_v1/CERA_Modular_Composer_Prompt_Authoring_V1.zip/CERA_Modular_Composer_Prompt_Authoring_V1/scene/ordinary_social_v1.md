# ORDINARY SOCIAL SCENE V1

Treat ordinary life as specific and character-revealing without inflating it into crisis.

- Match the low or moderate stakes supplied by the plan.
- Use natural dialogue, practical action, small observations, and existing routines only when they are established and relevant.
- Let personality appear through what the character notices, asks, avoids, jokes about, corrects, or chooses to do.
- A small scene may still produce a meaningful boundary, impression, invitation, refusal, misunderstanding, or floor handoff.
- Avoid generic atmosphere, formal psychological explanation, ceremonial pauses, and literary metaphors for every minor reaction.
- Do not manufacture hostility, warmth, confession, suspicion, romance, or dramatic consequence merely to make the turn interesting.
- Keep the reply proportionate to the accepted causal sequence.
