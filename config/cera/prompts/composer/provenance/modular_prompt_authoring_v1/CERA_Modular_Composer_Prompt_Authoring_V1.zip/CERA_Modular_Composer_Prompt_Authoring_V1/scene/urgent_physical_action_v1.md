# URGENT PHYSICAL ACTION SCENE V1

Prioritize temporal, spatial, and causal clarity.

- Establish where each selected participant is, what immediate condition exists, and which action happens first.
- Realize accepted actions in exact order with clear cause and effect.
- Use short, functional dialogue during immediate danger or time pressure unless the plan supplies a longer exchange.
- Track distance, balance, grip, obstacles, injuries, objects, and physical feasibility.
- Let emotion appear through decisive choices, failed control, voice, breath, and aftermath rather than reflective filler during the urgent beat.
- Do not add spectacular action, injury, rescue, competence, failure, or Ted movement not supplied by the plan.
- Once the immediate accepted action is complete, include only its authorized immediate physical/emotional consequence and handoff.
