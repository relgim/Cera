# Example and Craft-Fragment Selection Policy V1

## Principle

Select examples and Adult craft fragments by **unmet writing need**, not by mode quota.

There is no rigid maximum count or creative token ceiling during development. The selector should still prefer the smallest non-duplicative set that covers the actual needs of the accepted scene.

## Adult OFF

Select no explicit Adult fragments, explicit vocabulary guidance, or Adult examples.

## Adult ON and EX

ON and EX may select zero, one, or several relevant fragments/examples. More items are justified only when they teach different necessary skills.

Examples of distinct skills:

- direct anatomical vocabulary and register;
- gradual bodily response;
- body-position and clothing continuity;
- action–sensation–emotion integration;
- character-specific intimate dialogue;
- multi-participant floor and reaction ownership;
- specialized physical mechanics already authorized by the SequencePlan;
- climax or aftermath continuity already authorized by the SequencePlan.

## Selection procedure

1. Read the validated SequencePlan, Adult mode, content-family tags, topology, active characters, and current relationship/consent state.
2. Identify concrete realization risks not already handled by the stable modules and active-character packets.
3. Rank candidate fragments/examples by direct relevance and unique skill coverage.
4. Exclude wrong-act, wrong-register, wrong-participant, wrong-owner, wrong-consent, wrong-intensity, or specialized material not required by the scene.
5. Deduplicate items that teach substantially the same lesson.
6. Preserve provenance and the reason each item was selected.
7. Mark every example as noncanonical, nonhistorical, and noncopyable.

## Rejection criteria

Do not select an item merely because:

- Adult ON or EX is active;
- it is more graphic;
- it contains preferred vocabulary;
- it resembles a character generally;
- it was effective in an unrelated scene;
- it increases prompt length.

## Output influence boundary

Fragments and examples teach **how** to render an authorized event. They do not determine **what** happens.

They may not create:

- a new sexual act or escalation;
- a new participant;
- consent, desire, attraction, pain, pleasure, climax, or willingness;
- a relationship change;
- an objective fact or private history;
- a new metaphor or phrase that must be copied.

## Telemetry

Record selected IDs, versions, hashes, source provenance, selection reasons, byte/token contribution, and overlap/deduplication decisions. Do not treat size as a failure unless the actual provider context boundary is exceeded.
