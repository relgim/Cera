# Tone and Interiority Field Semantics V1

These are compact validated packet fields, not filesystem paths and not free-form prompt-module selectors. Codex should align the exact enum names with real consumers in the current DTO.

## Tone

Tone controls delivery, atmosphere, sentence pressure, and emotional register. It does not change the accepted event, scene function, participant list, consent state, or relationship consequence.

Useful bounded tone families may include:

- neutral or practical;
- warm;
- playful or light;
- awkward;
- tense;
- severe;
- intimate;
- somber;
- urgent.

A tone is a prior, not a quota. `tense` does not require hostility in every line. `playful` does not make a boundary unserious. `intimate` does not establish consent or romance. `urgent` does not authorize new action.

## Interiority level

### external_only

Use observable action, dialogue, timing, expression, vocal delivery, and environment. Do not narrate private thought.

### selective

Expose only the most useful owner-valid internal or bodily beats. Each should reveal interpretation, conflict, inhibition, tactic, or change rather than explain an obvious gesture.

### deep_pov

Stay closely within one explicitly selected viewpoint character. Render immediate perception, bodily sensation, conscious thought, uncertainty, motive conflict, self-correction, suppression, and chosen response when supported by the packet.

Deep POV does not permit invented biography, remembered incidents, habits, formative lessons, or objective narration of a subjective belief.

### alternating_limited

Use only when the packet explicitly selects more than one viewpoint owner. Keep transitions clear and preserve private knowledge separation. Do not rotate through every active character or mix several minds in one paragraph.

## Cross-field rules

- Topology determines who may own the floor; interiority determines whose private experience may be narrated.
- Scene function determines the main dramatic work; tone determines how it is delivered.
- Depth determines how fully the accepted sequence is developed; interiority does not create extra beats.
- Adult mode determines rendering explicitness; intimate tone or bodily interiority does not establish Adult eligibility or consent.
