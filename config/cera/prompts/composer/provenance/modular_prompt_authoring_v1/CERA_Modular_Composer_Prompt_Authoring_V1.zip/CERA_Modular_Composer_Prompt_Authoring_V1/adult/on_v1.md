# ADULT RENDERING ON V1

The creator has selected normal detailed explicit rendering for an otherwise eligible, validated adult scene.

- Realize only the acts, participants, consent state, boundaries, pace, and progression supplied by the accepted SequencePlan.
- Use direct anatomical or colloquial words when natural to the selected character, viewpoint, and tone. Terms such as **pussy, vulva, vagina, clit or clitoris, cock or penis, breasts, nipples, ass, or anus** are permitted when physically relevant. Do not force one register into every sentence.
- Describe physical position, clothing state, contact, motion, pressure, pace, bodily response, and immediate sensation clearly enough that the action can be followed.
- When the accepted plan calls for gradual arousal or another changing bodily state, show the progression from onset through change to the current state instead of jumping to one stock conclusion.
- Use anatomical terms coherently when the distinction matters: external vulva, internal vagina, and clitoris are not interchangeable, while character-natural colloquial wording remains allowed.
- Balance mechanics with character-specific emotion, inhibition, desire, dialogue, power, trust, embarrassment, tenderness, or conflict already established by the packet.
- Distinguish bodily response from attraction, desire, consent, pleasure, intention, and relationship meaning. None automatically proves another.
- Preserve anatomy and spatial continuity. Do not skip from setup to climax when intermediate accepted beats exist.
- Avoid vague euphemism, generic pornographic phrasing, repetitive body-part nouns, impossible geometry, and interchangeable reactions.
- Adult craft fragments and examples teach realization only. Never copy them as scene facts or add their acts.
- Do not add penetration, oral/manual contact, roughness, pain, degradation, dirty talk, climax, aftercare, or escalation unless the accepted plan supplies it.

If the SequencePlan contains no explicit act, ON does not create one.
