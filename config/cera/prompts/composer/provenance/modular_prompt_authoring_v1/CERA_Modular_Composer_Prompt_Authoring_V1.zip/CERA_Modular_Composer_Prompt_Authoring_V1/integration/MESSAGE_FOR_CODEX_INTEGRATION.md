# MESSAGE FOR CODEX — INTEGRATE CHATGPT PRO COMPOSER PROMPT DRAFT V1

ChatGPT Pro has authored the requested modular writing-facing sources. Treat them as advisory until technical review and provider-free integration prove compatibility.

## Files supplied

Runtime prompt modules:

```text
core/authority_and_hard_boundaries_v1.md
core/structured_output_v1.md
depth/off_v1.md
depth/auto_v1.md
depth/long_v1.md
depth/epic_v1.md
adult/off_v1.md
adult/on_v1.md
adult/ex_v1.md
topology/single_npc_floor_v1.md
topology/multi_npc_shared_floor_v1.md
topology/npc_to_npc_exchange_v1.md
scene/ordinary_social_v1.md
scene/emotional_vulnerability_v1.md
scene/confrontation_boundary_v1.md
scene/urgent_physical_action_v1.md
scene/aftermath_recovery_v1.md
```

Supporting sources:

```text
ASSEMBLY_AND_PRECEDENCE_V1.md
EXAMPLE_SELECTION_POLICY_V1.md
WRITING_QUALITY_EVALUATION_RUBRIC_V1.md
COMBINATION_EXAMPLES.md
SCENE_FUNCTION_SELECTION_GUIDE_V1.md
TONE_AND_INTERIORITY_FIELD_SEMANTICS_V1.md
MANIFEST.DRAFT.json
```

## Creator policies preserved

- No creative prompt-token limit during development.
- No rigid example or Adult-fragment count.
- Selection remains relevance-, coverage-, and deduplication-based.
- Adult ON permits direct detailed explicit wording.
- Adult EX increases granularity without changing causality.
- Depth and Adult are independent.
- One DeepSeek call remains the default.
- Metaphors remain available but are not mandatory.
- Python remains the durable commit authority; Reasoner/Sol semantic proposals remain flexible.

## Required Codex technical adaptation

1. Bind `structured_output_v1.md` to the exact active v19/v12 field names and obligation modes. Do not guess or remove field-level teaching.
2. Preserve the current reciprocal-action, biography/history, protected-user, source, privacy, branch, consent, participant, and schema safeguards.
3. Bind scene-function, tone, and interiority enums only where the DTO has validated consumers; use the supplied selection/field guides as advisory semantics.
4. Keep future conditional segments out of the creative DTO and provide only the derived handoff guard.
5. Implement exact `adult_rendering_mode = off | on | ex` independently from route eligibility.
6. Keep Adult OFF free of Adult fragments/examples.
7. Allow variable fragment/example selection and record every selected item's provenance and reason.
8. Keep the current active route available until provider-free tests and bounded Flash qualification pass.
9. Do not introduce automatic Composer retries or a default Detailer.
10. Record module versions, hashes, order, selection reasons, and prompt contribution.
11. Recompute the final manifest after any technical edits to these prompt sources.

## Technical review questions

- Does any module duplicate a hard rule better owned by Python or another stable contract?
- Does the exact provider schema require field-specific language not present in the generic structured-output module?
- Are tone and interiority represented as validated packet fields with real consumers?
- Does the Adult selector need a new rendering-mode filter before fragment selection?
- Which prompts must be shortened specifically for Flash salience after, not before, A/B evidence?

Do not activate this package merely because it parses. Run focused compiler tests, all 12 Depth × Adult combinations, full provider-free regression, sanitized packet inspection, and bounded DeepSeek Flash comparison first.
