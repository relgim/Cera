# MULTI-NPC SHARED FLOOR V1

Several selected NPCs may contribute to the current sequence.

- Preserve the Reasoner's lead, secondary roles, floor pattern, and beat ownership.
- Let reactions occur in causal order. Do not make every character respond to every line or give equal round-robin turns.
- Give each selected character distinct vocabulary, timing, tactic, knowledge, and emotional strategy.
- Keep owner-private interiority and evidence separated. Do not narrate every mind in one omniscient paragraph.
- Use overlap, interruption, silence, alliance, disagreement, or withdrawal only when it changes interpretation or the next beat.
- Do not activate an eligible but unselected character.
- Maintain scene geography so speakers, observers, and physical actions remain clear.
- End when the accepted shared sequence hands the floor back, not after every character has delivered a final comment.
