# Prompt Module Size Summary

Sizes are development telemetry only. They are not creative prompt limits.

| Order | Module ID | Path | Bytes |
|---:|---|---|---:|
| 100 | `cera.composer.core.authority_and_hard_boundaries.v1` | `core/authority_and_hard_boundaries_v1.md` | 5175 |
| 200 | `cera.composer.core.structured_output.v1` | `core/structured_output_v1.md` | 3032 |
| 800 | `cera.composer.depth.auto.v1` | `depth/auto_v1.md` | 1023 |
| 800 | `cera.composer.depth.epic.v1` | `depth/epic_v1.md` | 1237 |
| 800 | `cera.composer.depth.long.v1` | `depth/long_v1.md` | 1146 |
| 800 | `cera.composer.depth.off.v1` | `depth/off_v1.md` | 664 |
| 900 | `cera.composer.adult.ex.v1` | `adult/ex_v1.md` | 1656 |
| 900 | `cera.composer.adult.off.v1` | `adult/off_v1.md` | 911 |
| 900 | `cera.composer.adult.on.v1` | `adult/on_v1.md` | 2030 |
| 1000 | `cera.composer.topology.multi_npc_shared_floor.v1` | `topology/multi_npc_shared_floor_v1.md` | 904 |
| 1000 | `cera.composer.topology.npc_to_npc_exchange.v1` | `topology/npc_to_npc_exchange_v1.md` | 957 |
| 1000 | `cera.composer.topology.single_npc_floor.v1` | `topology/single_npc_floor_v1.md` | 733 |
| 1100 | `cera.composer.scene.aftermath_recovery.v1` | `scene/aftermath_recovery_v1.md` | 1017 |
| 1100 | `cera.composer.scene.confrontation_boundary.v1` | `scene/confrontation_boundary_v1.md` | 1007 |
| 1100 | `cera.composer.scene.emotional_vulnerability.v1` | `scene/emotional_vulnerability_v1.md` | 1029 |
| 1100 | `cera.composer.scene.ordinary_social.v1` | `scene/ordinary_social_v1.md` | 874 |
| 1100 | `cera.composer.scene.urgent_physical_action.v1` | `scene/urgent_physical_action_v1.md` | 867 |

**Runtime-module total:** 24262 bytes
