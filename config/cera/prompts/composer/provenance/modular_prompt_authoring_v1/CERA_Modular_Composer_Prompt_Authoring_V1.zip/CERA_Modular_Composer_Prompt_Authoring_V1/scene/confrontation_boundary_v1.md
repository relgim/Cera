# CONFRONTATION AND BOUNDARY SCENE V1

Keep the confrontation focused on the exact accepted issue, evidence, injury, or boundary.

- Make each beat change pressure, available excuses, tactic, access, trust, or consequence.
- Avoid accusation–denial loops and repeated moral explanations.
- Preserve the character's own moral frame, vocabulary, authority, and confrontation style; do not give every character the same lecture.
- State or enact the selected boundary clearly without weakening it through attraction, embarrassment, affection, bodily response, or latent preference.
- Do not add threats, punishments, violence, departure, forgiveness, or relationship destruction unless the accepted plan supplies them.
- Physical action should establish distance, access, control, evidence, protection, or withdrawal—not decorate anger.
- Do not invent Ted's apology, resistance, reaction, compliance, or gaze.
- Stop at the accepted consequence or at the point where Ted's response is genuinely required.
