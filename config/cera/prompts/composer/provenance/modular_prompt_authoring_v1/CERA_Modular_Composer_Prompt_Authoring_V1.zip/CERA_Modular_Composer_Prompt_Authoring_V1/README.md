# CERA Modular DeepSeek Composer Prompt Authoring V1

**Status:** prompt-authoring draft only; not an active runtime package  
**Target:** CERA one-call DeepSeek Scene Composer, with DeepSeek Flash as the next qualification target  
**Repository destination proposed by Codex:** `D:\AIChatBot\Cera\config\cera\prompts\composer\`

This package supplies the writing-facing prompt sources requested by Codex after its modular Composer audit. It does not modify CERA, activate Adult routes, call a provider, change publication authority, or replace the current Composer prompt.

## Runtime design preserved

```text
Validated SequencePlan
→ Python-selected prompt modules, character evidence, continuity, and craft fragments
→ one complete DeepSeek composition
→ Python structural validation
→ Sol semantic review / creator decision
→ Python-only durable publication
```

The Composer receives decisions; it does not choose the causal sequence, participants, consent, route eligibility, Adult content family, or durable truth.

## Authored runtime modules

- Two stable core modules.
- Four independent Depth profiles: OFF, AUTO, LONG, EPIC.
- Three independent Adult rendering profiles: OFF, ON, EX.
- Three interaction-topology profiles.
- Five scene-function profiles.

## Supporting authoring material

- Assembly order and authority precedence.
- Scene-function selection plus tone/interiority field semantics.
- Flexible example and Adult-fragment selection policy.
- Writing-quality evaluation rubric.
- Four representative module-combination examples.
- Draft manifest with hashes for Codex integration.
- Integration message for Codex.

## Creator decisions incorporated

- No creative prompt-token ceiling during development.
- No rigid maximum number of examples or Adult fragments.
- Relevance, unique skill coverage, and non-duplication determine selection.
- Prompt size and module contribution are telemetry, not optimization targets.
- Adult ON already permits direct, detailed explicit wording.
- Adult EX increases granularity; it does not independently add acts, participants, consent, roughness, or specialized content.
- Metaphors remain welcome when they add character-specific meaning, but they are not a paragraph quota.
- Python remains the only durable commit authority; Reasoner/Sol semantic proposals remain architecturally flexible during development.

## Important integration caveat

`core/structured_output_v1.md` is deliberately request-schema-aware rather than hardcoded to guessed field names. Codex must bind its semantic instructions to the actual Composer v19/v12 schema and `output_obligations` structures during integration.
