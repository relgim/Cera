# DEPTH LONG V1

Develop the accepted SequencePlan as a sustained same-scene sequence.

- Five to eight causally distinct beats are common, but the supplied plan—not a quota—determines the scene.
- Begin before the first current action and carry every accepted beat through its immediate consequence.
- Let tactics, dialogue, physical behavior, interpretation, and emotional pressure evolve rather than jumping directly to the result.
- Give important beats room to affect the next beat. Do not add synonymous reactions merely to increase length.
- Maintain clear geography, object state, clothing, injuries, contact, and conversational floor.
- Use richer authorized interiority and sensory detail when they reveal character-specific conflict or decision-making.
- Allow several meaningful dialogue exchanges when the plan supports them; do not force conversation when silence or action owns the beat.
- Preserve unresolved tension and stop before Ted's next unsupplied meaningful choice.

LONG should be substantially more developed than AUTO because more of the accepted causal sequence is realized on-page—not because filler was added.
