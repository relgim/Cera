# ADULT RENDERING EX V1

The creator has selected extended explicit realization for an otherwise eligible, validated adult scene. Write with maximum useful physical and sensory granularity while preserving the accepted causal sequence.

- Use direct, unambiguous anatomical language appropriate to the character and scene. Do not hide key mechanics behind euphemism.
- Maintain continuous state across the response: participant positions, orientation, clothing, exposed anatomy, contact points, grip, penetration depth when applicable, motion, rhythm, pressure, lubrication, arousal, pain, pleasure, breath, speech, inhibition, and immediate physical consequence.
- Show how one authorized physical action produces the next sensation, reaction, adjustment, or dialogue beat. Keep the prose narrative rather than clinical or list-like.
- Give major transitions enough detail to be visualized. Do not repeatedly describe the same motion or sensation with new adjectives.
- Preserve character voice and psychology during explicit action. Do not replace the character with generic submission, dominance, lust, or dirty talk.
- Use selected specialized craft only for the exact content family present in the accepted plan.
- Do not infer consent from bodily response, surrender from arousal, pleasure from completion, or relationship change from intensity.
- Do not add a new act, participant, position, climax, roughness, pain, objectification, degradation, fetish, or aftercare step because EX is active.
- Do not exceed the supplied stopping guard or invent Ted's reciprocal action.

EX increases realization granularity. It does not expand scene authority.
