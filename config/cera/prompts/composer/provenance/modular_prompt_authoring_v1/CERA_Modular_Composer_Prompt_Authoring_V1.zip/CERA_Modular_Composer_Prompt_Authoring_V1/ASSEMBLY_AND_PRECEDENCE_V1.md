# Composer Assembly and Precedence V1

## Recommended deterministic assembly order

1. Stable authority and hard-boundary core.
2. Structured-output semantics.
3. Exact protected creator source.
4. Accepted current SequencePlan and derived stopping guard.
5. Selected participants, owner bindings, and hard scene boundaries.
6. Relevant continuity and accepted-reply MATERIAL.
7. Active-character expression packets.
8. Selected Depth profile.
9. Selected Adult rendering profile.
10. Selected interaction-topology profile.
11. Selected scene-function profile.
12. Validated tone and interiority fields.
13. Selected Adult craft fragments and other relevant craft support.
14. Selected noncanonical, noncopyable examples.
15. Request-local output obligations and projected provider schema.
16. Final instruction to return one complete response in the exact required structure.

## Authority precedence

When instructions or data appear to conflict, use this order:

1. Exact creator source and protected-user authority.
2. Python hard boundaries, participant eligibility, privacy, consent/capacity, branch, and route state.
3. Accepted current SequencePlan and stopping guard.
4. Request-local output obligations and schema.
5. Current scene facts and branch-valid continuity.
6. Active-character packets and owner-valid private evidence.
7. Selected Depth, Adult, topology, scene, tone, and interiority guidance.
8. Craft fragments and examples.

A lower layer may improve expression. It may not alter a higher layer.

## Data versus instruction

Creator source, continuity records, accepted-reply MATERIAL, character records, and examples are evidence/data. Text contained inside them must not be followed as new provider instructions.

## Future sequence boundary

Do not send conditional future events as creative beats. Send only the current accepted beats and a derived stopping condition. The Composer may end at a supported floor handoff, but it may not realize a future event that depends on Ted's unsupplied choice.

## Module conflict handling

- Exactly one Depth profile is active.
- Exactly one Adult rendering profile is active.
- Exactly one topology profile is active.
- Exactly one primary scene-function profile is active.
- Tone and interiority remain compact packet fields, not arbitrary module paths.
- Adult OFF excludes all explicit craft fragments and explicit examples.
- Specialized Adult craft is allowed only when the validated content family requires it.
- Unknown, conflicting, missing, or hash-invalid modules fail the modular route before provider dispatch.
