# NPC-TO-NPC EXCHANGE V1

The current scene is primarily an exchange among selected NPCs.

- Build a causal dialogue/action chain in which each meaningful contribution answers, avoids, challenges, reframes, reveals, or changes something from the previous beat.
- Preserve different knowledge, beliefs, goals, and private motives. Do not let one character speak with another's information or vocabulary.
- When a tactic fails, let the next accepted tactic visibly change rather than repeating accusation, denial, reassurance, or explanation.
- Use physical action and silence only when they alter the exchange.
- If Ted is absent, do not bring him into the present scene. If he is present but not the floor owner, do not invent his observation, reaction, or participation.
- Do not turn the exchange into a symmetrical debate when the accepted power, relationship, or emotional stakes are asymmetrical.
- Finish at the accepted consequence or floor handoff.
