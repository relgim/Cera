# CERA Composer Writing-Quality Evaluation Rubric V1

Use this rubric for provider-free fixtures, DeepSeek Flash qualification, and paired comparison against the current V4 Pro baseline.

## Hard fidelity gates

A candidate cannot receive writing-quality acceptance when it:

- omits or reorders a required current beat;
- invents Ted's action, dialogue, private state, consent, or reciprocal behavior;
- activates an unselected participant;
- leaks wrong-owner private knowledge;
- contradicts exact creator source or the accepted SequencePlan;
- adds a new sexual act, participant, or escalation from Adult mode/examples alone;
- violates the request-local output contract.

## Scored dimensions: 1–5

### 1. Causal completeness

Does the response dramatize the entire accepted current sequence from the earliest beat through immediate consequence and handoff?

### 2. Scope discipline

Are added details compatible, scene-local, and non-causal? Is the response free from invented biography, routine, history, facts, or future events?

### 3. Proportional development

Does the selected Depth produce meaningfully appropriate development without under-writing, filler, synonymous beat splitting, or premature closure?

### 4. Character specificity

Could the active speaker usually be identified from syntax, vocabulary, tactic, moral frame, emotional strategy, and behavior without relying on a name tag?

### 5. Dialogue quality

Does dialogue sound spoken, react to exact prior material, change the scene, and avoid exposition or interchangeable moral lectures?

### 6. Physical and spatial continuity

Can the reader follow position, movement, objects, contact, clothing, injuries, and action order without contradictions?

### 7. Interiority quality

Is interiority owner-valid, proportionate, character-specific, and useful for revealing interpretation, conflict, inhibition, or strategy rather than explaining every gesture?

### 8. Metaphor and imagery

Do images arise naturally from character/worldview and add meaning without replacing clarity or repeating the same point?

### 9. Topology handling

Does floor ownership remain clear? Are multi-character reactions causally ordered and non-mechanical? Are inactive characters kept inactive?

### 10. Adult-mode fidelity

- OFF: mature but non-graphic; no explicit craft leakage.
- ON: direct and physically understandable when explicit action is planned; character-specific rather than evasive or generic.
- EX: more granular and continuous than ON without adding causality, acts, participants, or automatic extremity.

## Comparative evidence to retain

- time to first visible candidate;
- input and output tokens;
- selected modules/fragments/examples;
- beat realization rate;
- human Accept / DeepSeek rewrite / Reasoner replan choice;
- Sol concern type and human agreement;
- DeepSeek Flash versus V4 Pro blind preference.
