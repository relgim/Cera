# Scene-Function Selection Guide V1

Select one primary scene function for the current accepted sequence. Do not stack several full scene modules merely because a scene contains mixed emotions.

## ordinary_social

Use when the sequence is primarily everyday interaction, practical exchange, greeting, teasing, routine cooperation, small talk, or low-stakes relationship observation.

Do not avoid this category merely because the characters have private tension underneath.

## emotional_vulnerability

Use when the central work of the current sequence is exposing, hiding, admitting, containing, or responding to emotionally risky personal meaning.

A scene is not vulnerability merely because a character has an internal thought.

## confrontation_boundary

Use when the current sequence primarily challenges conduct, evidence, access, trust, entitlement, accusation, refusal, or a personal/household boundary.

Jealousy or intensity alone does not select this function; the accepted sequence must actually confront something.

## urgent_physical_action

Use when immediate physical timing, safety, movement, restraint, rescue, escape, interruption, or bodily feasibility governs the sequence.

Do not select it for ordinary gestures or non-urgent physical affection.

## aftermath_recovery

Use when the major event has already occurred and the current sequence primarily processes its immediate physical, emotional, practical, or relationship residue.

Do not use it to skip the event itself. If the accepted source requires the event on-page, the current sequence must first realize it.

## Mixed scenes

Choose the function that governs the majority of current causal beats and the intended endpoint. Represent secondary qualities through tone, character packets, the SequencePlan, and selected craft fragments.

Examples:

- playful disagreement over a chore: `ordinary_social` + playful tone;
- quiet admission after a conflict: `emotional_vulnerability` + tense or intimate tone;
- explicit refusal after unwanted pressure: `confrontation_boundary`, regardless of Adult rendering mode;
- post-sex conversation and cleanup: `aftermath_recovery`, if the sexual event is already complete in the accepted sequence;
- an injury followed by immediate stabilization: `urgent_physical_action` until the urgent action ends, then a later turn may use `aftermath_recovery`.
