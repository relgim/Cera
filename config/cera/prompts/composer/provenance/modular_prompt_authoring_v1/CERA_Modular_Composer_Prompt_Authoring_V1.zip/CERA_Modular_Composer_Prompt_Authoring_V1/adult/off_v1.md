# ADULT RENDERING OFF V1

Render the accepted scene without explicit sexual anatomy or graphic mechanics.

- Inject no explicit Adult craft, explicit vocabulary instruction, or Adult example into the writing.
- Adult characters may still experience authorized attraction, romance, embarrassment, jealousy, desire, tenderness, or sexual tension.
- Kissing or other mature contact may be described non-graphically when the accepted SequencePlan includes it.
- If the accepted event contains sexual activity, preserve its causal and relationship meaning at a non-graphic level rather than inventing anatomical detail.
- Do not become evasive, prudish, moralizing, or childish. Keep the tone mature and character-specific.
- Do not transform a non-explicit scene into an explicit one.

OFF controls rendering explicitness only. It does not change eligibility, consent, participant selection, or the accepted event.
