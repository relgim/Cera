# Representative Module Combinations

These are compiler-selection examples, not story prompts or mandatory routes.

## 1. AUTO + OFF + single NPC + ordinary social

```text
core.authority_and_hard_boundaries.v1
core.structured_output.v1
depth.auto.v1
adult.off.v1
topology.single_npc_floor.v1
scene.ordinary_social.v1
```

Expected result: a complete but proportionate ordinary sequence, character-specific dialogue, minimal unnecessary interiority, no explicit Adult craft.

## 2. LONG + OFF + multi-NPC + confrontation

```text
core.authority_and_hard_boundaries.v1
core.structured_output.v1
depth.long.v1
adult.off.v1
topology.multi_npc_shared_floor.v1
scene.confrontation_boundary.v1
```

Expected result: several evolving confrontation beats, distinct floor ownership, no accusation–denial loop, no graphic Adult rendering.

## 3. AUTO + ON + single NPC + emotional vulnerability

```text
core.authority_and_hard_boundaries.v1
core.structured_output.v1
depth.auto.v1
adult.on.v1
topology.single_npc_floor.v1
scene.emotional_vulnerability.v1
```

Adult fragment/example selection remains need-based. ON permits direct explicit vocabulary if the accepted SequencePlan contains explicit adult material, but does not create an act.

## 4. EPIC + EX + NPC-to-NPC + aftermath

```text
core.authority_and_hard_boundaries.v1
core.structured_output.v1
depth.epic.v1
adult.ex.v1
topology.npc_to_npc_exchange.v1
scene.aftermath_recovery.v1
```

Expected result: extended, physically continuous, character-specific aftermath across a fully accepted sequence. EX increases granularity only. Specialized fragments are selected only for content already authorized.
