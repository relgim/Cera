# Authoring Decisions

## 1. Prompt quality before prompt minimization

During development, CERA should send all information that is materially relevant to realizing the accepted SequencePlan. It should not trim valid evidence merely to satisfy an arbitrary internal token target.

This does not mean more text is automatically better. The compiler should remove irrelevant, duplicated, conflicting, superseded, wrong-owner, wrong-character, and wrong-content-family material. It should record prompt contribution by module so later optimization is evidence-led.

## 2. One stable core, conditional craft

Hard authority and protected-user rules belong in the always-present core. Depth, Adult rendering, topology, scene function, character expression, and examples are conditional. This prevents AUTO/OFF turns from carrying unrelated EPIC and Adult instructions.

## 3. Depth and Adult rendering are independent

Depth controls causal development and scene breadth. Adult mode controls rendering explicitness. Neither one changes the accepted SequencePlan.

## 4. Examples are teaching evidence, not authority

Examples are selected only when they teach a currently needed writing skill more clearly than the active modules and craft fragments already do. They never introduce a participant, act, consent state, relationship meaning, fact, or line that is absent from the validated packet.

There is no rigid example-count or prompt-token ceiling in this draft. Selection remains relevance- and coverage-based.

## 5. Metaphors

Metaphors are permitted and often desirable. They should arise from the active character's worldview, sharpen a meaningful transition, and avoid repeating a meaning already carried by action or dialogue. Concrete action and state clarity take priority, especially in explicit scenes.

## 6. Structural invalidity versus writing concern

A writing or continuity concern may be severe and still be presented to the creator for judgment. A structurally invalid result remains a separate publication-eligibility state. Prompt prose does not weaken Python's authority over that distinction.
