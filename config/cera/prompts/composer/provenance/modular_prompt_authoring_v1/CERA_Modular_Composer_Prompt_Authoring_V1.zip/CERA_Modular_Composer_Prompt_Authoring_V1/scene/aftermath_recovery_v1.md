# AFTERMATH AND RECOVERY SCENE V1

Render the immediate residue of an accepted event without skipping directly to repair or summary.

- Preserve physical state, location, clothing, objects, injuries, bodily response, silence, and emotional pressure left by the event.
- Let selected characters interpret the same event differently according to their knowledge and relationship.
- Use practical actions, changed distance, fragmented dialogue, care, withdrawal, cleanup, checking, or boundary-setting only when authorized by the plan.
- Do not make apology equal forgiveness, care equal trust, bodily calm equal emotional recovery, or accepted intimacy equal permanent relationship change.
- Avoid a narrator summary of lessons learned or future meaning.
- In explicit scenes, preserve relevant physical and emotional state through the immediate aftermath; do not add climax, aftercare, or commitment unless supplied.
- End at the first stable accepted handoff, unresolved silence, practical next step, or consequence.
