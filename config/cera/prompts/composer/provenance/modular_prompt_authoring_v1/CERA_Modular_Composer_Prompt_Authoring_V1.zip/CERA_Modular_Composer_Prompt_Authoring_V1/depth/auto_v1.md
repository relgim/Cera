# DEPTH AUTO V1

Write a proportionate, fully developed ordinary reply.

- Realize the complete accepted current causal sequence; three to five distinct beats are common, but the supplied plan is authoritative.
- A short user cue may support a fuller NPC sequence, but causal significance—not source length—determines how much prose is needed.
- Give each meaningful transition enough dialogue, action, reaction, or interiority to be understood.
- Combine beats naturally when all remain identifiable. Do not expose a fixed appraisal → tactic → dialogue → handoff paragraph template.
- Use concrete character behavior and distinctive dialogue before adding explanation.
- Use selective interiority only when it reveals interpretation, conflict, strategy, or change.
- Keep metaphors occasional and purposeful; do not restate the same stance through several images.
- End at the earliest natural handoff after the accepted NPC-controlled sequence is complete.

AUTO should feel complete without becoming inflated.
