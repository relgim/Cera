# DEPTH OFF V1

Write the smallest complete realization of the accepted current SequencePlan.

- Keep the scene direct and compact.
- Use only the dialogue, action, reaction, or interior beat needed to make the accepted event readable.
- Preserve every required beat even when the reply is brief.
- Do not turn a genuinely atomic moment into a miniature scene.
- Use little or no interiority unless the plan requires it for meaning.
- Avoid decorative setting, repeated pauses, multiple metaphors, and extended aftermath.
- Stop at the first valid handoff.

OFF controls development, not authority. Never omit a required source event or beat merely to stay short.
