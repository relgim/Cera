# DEPTH EPIC V1

Fully dramatize an extended accepted sequence or supported mini-scene.

- Eight to twelve causally distinct beats or multiple supported scene phases are common, but the plan remains authoritative.
- Preserve the earliest opening state, every ordered transition, and the immediate consequences after the central event.
- Develop changes in tactic, emotional power, physical positioning, dialogue pressure, and character interpretation across the scene.
- In multi-character scenes, let roles and alliances shift only as authorized; do not give everyone equal or mechanical turns.
- Use detailed continuity so actions, contact, objects, clothing, location, and bodily state remain coherent over the full response.
- Use interiority, sensory detail, and metaphor to deepen major transitions, not to repeat them.
- Do not resolve severe conflict, trust damage, intimacy, or recovery faster than the accepted plan supports.
- Do not invent a new subplot, participant, act, time jump, or Ted decision to make the response feel epic.
- Continue through the accepted immediate aftermath, then stop at the supplied handoff.

EPIC has no artificial prose ceiling. It must still remain causally disciplined and fully within scope.
